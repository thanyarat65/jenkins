// top55.js - ปรับปรุงตามโครงสร้าง maindash.js และแก้ไขปัญหา infinite resizing

// Dictionary เก็บ chart instances ทั้งหมด
const chartInstances = {};

// เก็บค่า filter ล่าสุดที่ใช้กับแต่ละ chart
const chartFilters = {
    students: {},
    professors: {},
    jobs: {},
    skills: {}
};

// ========== ส่วนเริ่มต้นการทำงาน ==========
document.addEventListener("DOMContentLoaded", function() {
    // ป้องกันการ resize ที่ไม่ต้องการด้วยการเพิ่ม class ให้กับ body
    document.body.classList.add('chart-render-ready');
    
    // โหลด options สำหรับ filters ทั้งหมด
    Promise.all([
        loadCategoryOptions(),
        loadStatusOptions(),
        loadRewardOptions(),
        loadTeacherOptions(),
        loadSkillOptions(),
        loadMajorOptions()
    ]).then(() => {
        // เริ่มต้นสร้าง charts ก่อนการใส่ข้อมูล
        initializeCharts();
        
        // โหลดข้อมูลทุก chart ด้วย filters เริ่มต้น
        loadAllCharts();
        
        // บันทึกค่า filters เริ่มต้นเพื่อใช้ตอน reset
        saveDefaultFilters();
    }).catch(err => {
        console.error("Error loading filter options:", err);
        // ถึงแม้จะมี error ก็ยังลองโหลด charts
        initializeCharts();
        loadAllCharts();
    });
});

// บันทึกค่า filters เริ่มต้น
function saveDefaultFilters() {
    for (let chartId in chartFilters) {
        chartFilters[chartId] = getChartFilters(chartId);
    }
}

// ฟังก์ชันเริ่มต้นใช้ก่อนวาดกราฟใดๆ - เคลียร์และเตรียม canvas
function prepareCanvasForChart(canvasId) {
    // หา container ที่มี canvas อยู่
    const container = document.getElementById(canvasId).closest('.chart-container');
    if (!container) {
        console.error(`Container for ${canvasId} not found`);
        return null;
    }
    
    // ลบ canvas เดิมและสร้างใหม่เพื่อป้องกันปัญหา stacking
    const oldCanvas = document.getElementById(canvasId);
    const newCanvas = document.createElement('canvas');
    newCanvas.id = canvasId;
    newCanvas.style.width = '100%';
    newCanvas.style.height = '100%';
    newCanvas.style.maxHeight = '400px';
    
    // แทนที่ canvas เดิมด้วย canvas ใหม่
    container.innerHTML = '';
    container.appendChild(newCanvas);
    
    // ป้องกันไม่ให้มีการปรับขนาดแบบ infinite
    container.style.height = '400px';
    container.style.maxHeight = '400px';
    container.style.width = '100%';
    container.style.position = 'relative';
    container.style.overflow = 'hidden';
    
    return newCanvas;
}

// สร้าง charts เปล่าไว้ก่อน
function initializeCharts() {
    renderBarChart("studentsChart", [], [], "Students", "#FF6B00");
    renderBarChart("professorsChart", [], [], "Professors", "#4B0082");
    renderPieChart("jobsChart", [], [], ["#FFD700", "#C0C0C0", "#CD7F32", "#FF6B00", "#4B0082"], "Popular Jobs");
    renderGroupedBarChart("supplyDemandChart", [], [], [], "Supply", "Demand");
}

// โหลดข้อมูลทุก chart
function loadAllCharts() {
    loadChartData('students', getChartFilters('students'));
    loadChartData('professors', getChartFilters('professors'));
    loadChartData('jobs', getChartFilters('jobs'));
    loadChartData('skills', getChartFilters('skills'));
}

// แก้ไขปัญหาการขยายของ chart หลังจากสร้างแล้ว
function fixChartResizing(canvasId) {
    // ดึง DOM elements ที่เกี่ยวข้อง
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const container = canvas.closest('.chart-container');
    if (!container) return;
    
    // กำหนดขนาดของ container และ canvas ให้แน่นอน
    container.style.height = '400px';
    container.style.maxHeight = '400px';
    container.style.width = '100%';
    container.style.overflow = 'hidden';
    
    // ค้นหา canvas wrapper ที่สร้างโดย Chart.js และป้องกันการขยาย
    const wrappers = container.querySelectorAll('div');
    wrappers.forEach(wrapper => {
        if (wrapper.contains(canvas)) {
            wrapper.style.height = '100%';
            wrapper.style.maxHeight = '400px';
            wrapper.style.width = '100%';
            wrapper.style.overflow = 'hidden';
        }
    });
    
    // ป้องกันการขยายของ canvas
    canvas.style.maxHeight = '400px';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    
    // ปรับ style ของ chart elements
    const chartElements = container.querySelectorAll('.chartjs-size-monitor, .chartjs-render-monitor');
    chartElements.forEach(el => {
        el.style.maxHeight = '400px';
        el.style.position = 'absolute';
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.overflow = 'hidden';
        el.style.pointerEvents = 'none';
    });
}

// ========== ส่วนการโหลด Filter Options ==========

// โหลด Category Options
function loadCategoryOptions() {
    return fetch("api/api.php?endpoint=categories-list")
        .then(res => res.json())
        .then(data => {
            // โหลดลงใน global filter
            const categorySelect = document.getElementById("category");
            if (categorySelect) {
                categorySelect.innerHTML = '<option value="">All</option>';
            }
            
            // โหลดลงใน chart-specific filters
            const chartSelects = [
                "professors_category", 
                "jobs_category"
            ];
            
            data.forEach(item => {
                const opt = document.createElement("option");
                opt.value = item.job_categories_id;
                opt.textContent = item.categories_name;
                
                // เพิ่มลงใน global filter
                if (categorySelect) {
                    categorySelect.appendChild(opt.cloneNode(true));
                }
                
                // เพิ่มลงใน chart-specific filters
                chartSelects.forEach(selectId => {
                    const select = document.getElementById(selectId);
                    if (select) {
                        select.appendChild(opt.cloneNode(true));
                    }
                });
            });
        }).catch(err => {
            console.error("Error loading categories:", err);
        });
}

// โหลด Status Options
function loadStatusOptions() {
    return fetch("api/api.php?endpoint=status-list")
        .then(res => res.json())
        .then(data => {
            // โหลดลงใน global filter
            const statusSelect = document.getElementById("status");
            if (statusSelect) {
                statusSelect.innerHTML = '<option value="">All</option>';
            }
            
            // โหลดลงใน chart-specific filters
            const chartSelects = ["jobs_status"];
            
            data.forEach(item => {
                const opt = document.createElement("option");
                opt.value = item.job_status_id;
                opt.textContent = item.job_status_name;
                
                // เพิ่มลงใน global filter
                if (statusSelect) {
                    statusSelect.appendChild(opt.cloneNode(true));
                }
                
                // เพิ่มลงใน chart-specific filters
                chartSelects.forEach(selectId => {
                    const select = document.getElementById(selectId);
                    if (select) {
                        select.appendChild(opt.cloneNode(true));
                    }
                });
            });
        }).catch(err => {
            console.error("Error loading status options:", err);
        });
}

// ตำแหน่ง: เพิ่มหลังฟังก์ชัน loadCategoryOptions และ loadStatusOptions

// เพิ่มฟังก์ชันโหลด Reward Options (ถ้ายังไม่มี)
function loadRewardOptions() {
  return fetch("api/api.php?endpoint=reward-list")
      .then(res => res.json())
      .then(data => {
          // โหลดลงใน global filter
          const rewardSelect = document.getElementById("reward");
          if (rewardSelect) {
              rewardSelect.innerHTML = '<option value="">All</option>';
          }
          
          // โหลดลงใน chart-specific filters
          const chartSelects = ["jobs_reward"];
          
          data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.reward_type_id;
              opt.textContent = item.reward_name;
              
              // เพิ่มลงใน global filter
              if (rewardSelect) {
                  rewardSelect.appendChild(opt.cloneNode(true));
              }
              
              // เพิ่มลงใน chart-specific filters
              chartSelects.forEach(selectId => {
                  const select = document.getElementById(selectId);
                  if (select) {
                      select.appendChild(opt.cloneNode(true));
                  }
              });
          });
      }).catch(err => {
          console.error("Error loading reward options:", err);
      });
}

// เพิ่มฟังก์ชันโหลด Teacher Options (ถ้ายังไม่มี)
function loadTeacherOptions() {
  return fetch("api/api.php?endpoint=teacher-list")
      .then(res => res.json())
      .then(data => {
          // โหลดลงใน global filter
          const teacherSelect = document.getElementById("teacher");
          if (teacherSelect) {
              teacherSelect.innerHTML = '<option value="">All</option>';
          }
          
          // โหลดลงใน chart-specific filters
          const chartSelects = ["jobs_teacher"];
          
          data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.teachers_id;
              opt.textContent = item.name;
              
              // เพิ่มลงใน global filter
              if (teacherSelect) {
                  teacherSelect.appendChild(opt.cloneNode(true));
              }
              
              // เพิ่มลงใน chart-specific filters
              chartSelects.forEach(selectId => {
                  const select = document.getElementById(selectId);
                  if (select) {
                      select.appendChild(opt.cloneNode(true));
                  }
              });
          });
      }).catch(err => {
          console.error("Error loading teacher options:", err);
      });
}

// โหลด Skill Options
function loadSkillOptions() {
    return fetch("api/api.php?endpoint=skills-list")
        .then(res => res.json())
        .then(data => {
            // โหลดลงใน global filter
            const skillSelect = document.getElementById("skillFilter");
            if (skillSelect) {
                skillSelect.innerHTML = '<option value="">All</option>';
            }
            
            // โหลดลงใน skills chart filter
            const skillsSelect = document.getElementById("skills_skill");
            if (skillsSelect) {
                skillsSelect.innerHTML = '<option value="">All</option>';
            }
            
            data.forEach(item => {
                const opt = document.createElement("option");
                opt.value = item.skills_id;
                opt.textContent = item.skills_name;
                
                // เพิ่มลงใน global filter
                if (skillSelect) {
                    skillSelect.appendChild(opt.cloneNode(true));
                }
                
                // เพิ่มลงใน skills chart filter
                if (skillsSelect) {
                    skillsSelect.appendChild(opt.cloneNode(true));
                }
            });
        }).catch(err => {
            console.error("Error loading skills options:", err);
        });
}

// โหลด Major Options
function loadMajorOptions() {
    return fetch("api/api.php?endpoint=major-list")
        .then(res => res.json())
        .then(data => {
            // โหลดลงใน major selects ทั้งหมด
            const majorSelects = [
                "students_major",
                "professors_major",
                "skills_major"
            ];
            
            majorSelects.forEach(selectId => {
                const select = document.getElementById(selectId);
                if (select) {
                    select.innerHTML = '<option value="">All</option>';
                    data.forEach(item => {
                        const opt = document.createElement("option");
                        opt.value = item.major_id;
                        opt.textContent = item.major_name;
                        select.appendChild(opt.cloneNode(true));
                    });
                }
            });
        }).catch(err => {
            console.error("Error loading major options:", err);
        });
}

// ========== ส่วนการจัดการ Filters ==========

// Apply filter ทั้งหมดให้ทุก chart (Global Filter)
function applyFilters() {
    const globalFilters = getGlobalFilters();
    
    // นำ global filters ไปใช้กับทุก chart
    for (let chartId in chartFilters) {
        // ใช้ {...globalFilters} เพื่อสร้าง copy ของ object
        chartFilters[chartId] = {...globalFilters};
        loadChartData(chartId, chartFilters[chartId]);
        updateFilterStatus(chartId, chartFilters[chartId]);
    }
}

// Reset filter ทั้งหมด
function resetFilters() {
    // Reset global filter inputs
    document.getElementById("startDate").value = '';
    document.getElementById("endDate").value = '';
    document.getElementById("category").value = '';
    document.getElementById("status").value = '';
    document.getElementById("reward").value = '';
    document.getElementById("teacher").value = '';
    document.getElementById("skillFilter").value = '';
    
    // Reset filter และโหลดข้อมูลใหม่สำหรับทุก chart
    for (let chartId in chartFilters) {
        resetChartFilters(chartId);
    }
}

// Apply filter สำหรับ chart เฉพาะ
function applyChartFilters(chartId) {
    // ดึงค่า filter จาก UI
    const filters = getChartFilters(chartId);
    
    // บันทึกค่า filter ล่าสุด
    chartFilters[chartId] = {...filters};
    
    // อัปเดตสถานะการใช้งาน filter
    updateFilterStatus(chartId, filters);
    
    // โหลดข้อมูลใหม่
    loadChartData(chartId, filters);
}

// Reset filter สำหรับ chart เฉพาะ
function resetChartFilters(chartId) {
    // Reset inputs สำหรับ chart นี้
    const prefix = chartId + '_';
    
    // Reset selects
    document.querySelectorAll(`select[id^="${prefix}"]`).forEach(el => {
        el.value = '';
    });
    
    // Reset date inputs
    document.querySelectorAll(`input[type="date"][id^="${prefix}"]`).forEach(el => {
        el.value = '';
    });
    
    // กรณีพิเศษสำหรับ student sort
    if (chartId === 'students' && document.getElementById('studentSort')) {
        document.getElementById('studentSort').value = 'rating';
    }
    
    // กรณีพิเศษสำหรับ skills show only
    if (chartId === 'skills' && document.getElementById('skills_showOnly')) {
        document.getElementById('skills_showOnly').value = 'all';
    }
    
    // ล้างค่า filter ที่บันทึกไว้
    chartFilters[chartId] = {};
    
    // โหลดข้อมูลใหม่โดยไม่มี filter
    loadChartData(chartId, {});
    
    // อัปเดตสถานะ filter
    updateFilterStatus(chartId, {});
}

// ดึงค่า Global Filter
function getGlobalFilters() {
    return {
        start: document.getElementById("startDate").value || '',
        end: document.getElementById("endDate").value || '',
        category: document.getElementById("category").value || '',
        status: document.getElementById("status").value || '',
        reward: document.getElementById("reward").value || '',
        teacher: document.getElementById("teacher").value || '',
        skill: document.getElementById("skillFilter").value || ''
    };
}

// ดึงค่า filter สำหรับ chart เฉพาะ
function getChartFilters(chartId) {
    const filters = {};
    const prefix = chartId + '_';
    
    // ดึงค่า filter พื้นฐานที่ใช้กับหลาย chart
    if (document.getElementById(prefix + 'startDate')) {
        filters.start = document.getElementById(prefix + 'startDate').value || '';
    }
    
    if (document.getElementById(prefix + 'endDate')) {
        filters.end = document.getElementById(prefix + 'endDate').value || '';
    }
    
    if (document.getElementById(prefix + 'category')) {
        filters.category = document.getElementById(prefix + 'category').value || '';
    }
    
    if (document.getElementById(prefix + 'status')) {
        filters.status = document.getElementById(prefix + 'status').value || '';
    }
    
    if (document.getElementById(prefix + 'major')) {
        filters.major = document.getElementById(prefix + 'major').value || '';
    }
    
    if (document.getElementById(prefix + 'year')) {
        filters.year = document.getElementById(prefix + 'year').value || '';
    }
    
    if (document.getElementById(prefix + 'limit')) {
        filters.limit = document.getElementById(prefix + 'limit').value || '';
    }
    if (document.getElementById(prefix + 'reward')) {
      filters.reward = document.getElementById(prefix + 'reward').value || '';
  }
  
  if (document.getElementById(prefix + 'teacher')) {
      filters.teacher = document.getElementById(prefix + 'teacher').value || '';
  }
    
    // filter เฉพาะสำหรับแต่ละ chart
    switch(chartId) {
        case 'students':
            if (document.getElementById('studentSort')) {
                filters.sort = document.getElementById('studentSort').value || 'rating';
            }
            break;
            
        case 'skills':
            if (document.getElementById('skills_skill')) {
                filters.skill = document.getElementById('skills_skill').value || '';
            }
            if (document.getElementById('skills_showOnly')) {
                filters.showOnly = document.getElementById('skills_showOnly').value || 'all';
            }
            break;
    }
    
    return filters;
}

// อัปเดตสถานะการใช้ filter
function updateFilterStatus(chartId, filters) {
    const chartElement = document.getElementById(chartId + 'Chart');
    if (!chartElement) {
        console.error(`Chart element not found: ${chartId}Chart`);
        return;
    }
    
    const filterStatusDiv = document.createElement('div');
    filterStatusDiv.className = 'filter-status small text-muted mt-2';
    filterStatusDiv.innerHTML = '<strong>Active Filters:</strong> ';
    
    // สร้างรายการ filter ที่ใช้งาน
    const activeFilters = [];
    
    if (filters.start && filters.end) {
        activeFilters.push(`Date: ${filters.start} to ${filters.end}`);
    } else if (filters.start) {
        activeFilters.push(`Date from: ${filters.start}`);
    } else if (filters.end) {
        activeFilters.push(`Date until: ${filters.end}`);
    }
    
    if (filters.category) {
        const categorySelect = document.getElementById(chartId + '_category') || document.getElementById("category");
        if (categorySelect) {
            const selectedOption = [...categorySelect.options].find(opt => opt.value === filters.category);
            if (selectedOption) {activeFilters.push(`Category: ${selectedOption.text}`);
          } else {
              activeFilters.push(`Category ID: ${filters.category}`);
          }
      } else {
          activeFilters.push(`Category ID: ${filters.category}`);
      }
  }
  
  if (filters.status) {
      const statusSelect = document.getElementById(chartId + '_status') || document.getElementById("status");
      if (statusSelect) {
          const selectedOption = [...statusSelect.options].find(opt => opt.value === filters.status);
          if (selectedOption) {
              activeFilters.push(`Status: ${selectedOption.text}`);
          } else {
              activeFilters.push(`Status ID: ${filters.status}`);
          }
      } else {
          activeFilters.push(`Status ID: ${filters.status}`);
      }
  }
  
  if (filters.major) {
      const majorSelect = document.getElementById(chartId + '_major');
      if (majorSelect) {
          const selectedOption = [...majorSelect.options].find(opt => opt.value === filters.major);
          if (selectedOption) {
              activeFilters.push(`Major: ${selectedOption.text}`);
          } else {
              activeFilters.push(`Major ID: ${filters.major}`);
          }
      } else {
          activeFilters.push(`Major ID: ${filters.major}`);
      }
  }
  
  if (filters.year) {
      activeFilters.push(`Year: ${filters.year}`);
  }
  
  if (filters.skill) {
      const skillSelect = document.getElementById(chartId + '_skill') || document.getElementById("skillFilter");
      if (skillSelect) {
          const selectedOption = [...skillSelect.options].find(opt => opt.value === filters.skill);
          if (selectedOption) {
              activeFilters.push(`Skill: ${selectedOption.text}`);
          } else {
              activeFilters.push(`Skill ID: ${filters.skill}`);
          }
      } else {
          activeFilters.push(`Skill ID: ${filters.skill}`);
      }
  }
  
  // ฟิลเตอร์เฉพาะ chart
  if (chartId === 'students' && filters.sort) {
      activeFilters.push(`Sort by: ${filters.sort === 'rating' ? 'Rating' : 'Accept Count'}`);
  }
  
  if (chartId === 'skills' && filters.showOnly && filters.showOnly !== 'all') {
      activeFilters.push(`Show only: ${filters.showOnly === 'shortage' ? 'Shortage' : 'Surplus'}`);
  }
  
  // แสดงรายการ filter ที่ใช้งาน หรือข้อความว่าไม่มี filter ถ้าไม่ได้เลือกอะไร
  if (activeFilters.length > 0) {
      filterStatusDiv.innerHTML += activeFilters.join(', ');
  } else {
      filterStatusDiv.innerHTML += 'None (showing all data)';
  }
  
  // ลบสถานะเดิมและเพิ่มสถานะใหม่
  const chartContainer = chartElement.closest('.chart-container');
  if (chartContainer) {
      const oldStatus = chartContainer.querySelector('.filter-status');
      if (oldStatus) oldStatus.remove();
      
      chartContainer.appendChild(filterStatusDiv);
  }
}

// ========== ส่วนการโหลดข้อมูล Chart ==========

// โหลดข้อมูลสำหรับ chart ที่ระบุ
function loadChartData(chartId, filters) {
  switch(chartId) {
      case 'students':
          loadStudentsChart(filters);
          break;
          
      case 'professors':
          loadProfessorsChart(filters);
          break;
          
      case 'jobs':
          loadJobsChart(filters);
          break;
          
      case 'skills':
          loadSkillsChart(filters);
          break;
  }
}

// โหลดข้อมูล Top Students Chart
function loadStudentsChart(filters) {
  // สร้าง URLSearchParams
  const params = new URLSearchParams({ endpoint: "top5-students" });
  
  // เพิ่ม filter ทั้งหมดที่ไม่ว่าง
  Object.entries(filters).forEach(([key, value]) => {
      if (value) params.set(key, value);
  });
  
  // ตรวจสอบว่ามี sort param หรือไม่ ถ้าไม่มีให้เป็น rating
  if (!params.has('sort')) {
      params.set('sort', 'rating');
  }
  
  fetch("api/api.php?" + params.toString())
      .then(res => {
          if (!res.ok) {
              throw new Error(`API responded with status ${res.status}`);
          }
          return res.json();
      })
      .then(data => {
          // จำกัดให้แสดงแค่ 5 อันดับแรก
          const top5 = data.slice(0, 5);
          const labels = top5.map(d => d.name);
          let values, chartLabel;
          
          if (params.get('sort') === "accept") {
              values = top5.map(d => Number(d.accept_count) || 0);
              chartLabel = "Accepted Jobs";
          } else {
              values = top5.map(d => Number(d.avg_rating) || 0);
              chartLabel = "Avg Rating";
          }
          
          renderBarChart("studentsChart", labels, values, chartLabel, "#FF6B00");
          
          // อัปเดตสถานะการใช้ filter
          updateFilterStatus('students', filters);
      })
      .catch(err => {
          console.error("Error fetching top5-students:", err);
          handleChartError("studentsChart", err);
      });
}

// โหลดข้อมูล Top Professors Chart
function loadProfessorsChart(filters) {
  // สร้าง URLSearchParams
  const params = new URLSearchParams({ endpoint: "top-professors" });
  
  // เพิ่ม filter ทั้งหมดที่ไม่ว่าง
  Object.entries(filters).forEach(([key, value]) => {
      if (value) params.set(key, value);
  });
  
  fetch("api/api.php?" + params.toString())
      .then(res => {
          if (!res.ok) {
              throw new Error(`API responded with status ${res.status}`);
          }
          return res.json();
      })
      .then(data => {
          const labels = data.map(d => d.name);
          const values = data.map(d => Number(d.job_count));
          
          renderBarChart("professorsChart", labels, values, "Posted Jobs", "#4B0082");
          
          // อัปเดตสถานะการใช้ filter
          updateFilterStatus('professors', filters);
      })
      .catch(err => {
          console.error("Error fetching top-professors:", err);
          handleChartError("professorsChart", err);
      });
}

// โหลดข้อมูล Most Popular Jobs Chart
// ตำแหน่ง: ในฟังก์ชัน loadJobsChart

function loadJobsChart(filters) {
  // สร้าง URLSearchParams
  const params = new URLSearchParams({ endpoint: "top-jobs" });
  
  // เพิ่ม filter ทั้งหมดที่ไม่ว่าง
  Object.entries(filters).forEach(([key, value]) => {
      if (value) params.set(key, value);
  });
  
  fetch("api/api.php?" + params.toString())
      .then(res => {
          if (!res.ok) {
              throw new Error(`API responded with status ${res.status}`);
          }
          return res.json();
      })
      .then(data => {
          // จำกัดข้อมูลตาม limit ถ้ามีการกำหนด
          let filteredData = [...data];
          
          // กรองข้อมูลที่มีจำนวน > 0 เท่านั้น
          filteredData = filteredData.filter(d => Number(d.total_applications) > 0);
          
          // ถ้ามีการกำหนด limit กรองตาม limit
          if (filters.limit && parseInt(filters.limit) > 0) {
              filteredData = filteredData.slice(0, parseInt(filters.limit));
          }
          
          const labels = filteredData.map(d => d.title);
          const values = filteredData.map(d => Number(d.total_applications));
          
          renderPieChart(
              "jobsChart", 
              labels, 
              values, 
              ["#FFD700", "#C0C0C0", "#CD7F32", "#FF6B00", "#4B0082"]
          );
          
          // อัปเดตสถานะการใช้ filter
          updateFilterStatus('jobs', filters);
      })
      .catch(err => {
          console.error("Error fetching top-jobs:", err);
          handleChartError("jobsChart", err);
      });
}

// โหลดข้อมูล Skills Supply vs Demand Chart
function loadSkillsChart(filters) {
  // สร้าง URLSearchParams
  const params = new URLSearchParams({ endpoint: "supply-demand-skills" });
  
  // Log เพื่อดูค่า filters ที่ได้รับ
  console.log("Skills filters:", filters);
  
  // เพิ่ม filter ทั้งหมดที่ไม่ว่าง
  Object.entries(filters).forEach(([key, value]) => {
      if (value) {
          params.set(key, value);
          console.log(`Setting ${key}=${value} for skills chart`);
      }
  });
  
  console.log("Final params for skills:", params.toString());
  
  fetch("api/api.php?" + params.toString())
      .then(res => {
          if (!res.ok) {
              throw new Error(`API responded with status ${res.status}`);
          }
          return res.json();
      })
      .then(data => {
          console.log("Skills data received:", data);
          
          // กรองทักษะตามเงื่อนไข Supply vs Demand
          let filtered;
          
          if (filters.showOnly === 'shortage') {
              // แสดงเฉพาะทักษะที่ demand > supply
              filtered = data.filter(d => Number(d.demand) > Number(d.supply));
          } else if (filters.showOnly === 'surplus') {
              // แสดงเฉพาะทักษะที่ supply > demand
              filtered = data.filter(d => Number(d.supply) > Number(d.demand));
          } else {
              // แสดงทุกทักษะที่มีค่าไม่เป็น 0
              filtered = data.filter(d => Number(d.supply) > 0 || Number(d.demand) > 0);
          }
          
          const labels = filtered.map(d => d.skills_name);
          const supplyValues = filtered.map(d => Number(d.supply));
          const demandValues = filtered.map(d => Number(d.demand));
          
          renderGroupedBarChart(
              "supplyDemandChart", 
              labels, 
              supplyValues, 
              demandValues, 
              "Supply", 
              "Demand"
          );
          
          // อัปเดตสถานะการใช้ filter
          updateFilterStatus('skills', filters);
      })
      .catch(err => {
          console.error("Error fetching supply-demand-skills:", err);
          handleChartError("supplyDemandChart", err);
      });
}

// จัดการกรณีเกิด error ในการโหลดข้อมูล chart
function handleChartError(canvasId, error) {
  const chartContainer = document.getElementById(canvasId).closest('.chart-container');
  if (chartContainer) {
      chartContainer.innerHTML = `
          <div class="alert alert-danger">Error loading data: ${error.message}</div>
          <canvas id="${canvasId}"></canvas>
      `;
  }
}

// ========== ส่วน Chart Renderers ==========

// วาดกราฟแท่ง (Bar Chart)
function renderBarChart(canvasId, labels, values, labelText, bgColor) {
  if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
      delete chartInstances[canvasId];
  }
  
  // จัดการกรณีไม่มีข้อมูล
  if (!labels || labels.length === 0) {
      showNoDataMessage(canvasId);
      return;
  }
  
  // เตรียม canvas ใหม่ที่สะอาด
  const canvas = prepareCanvasForChart(canvasId);
  if (!canvas) return;
  
  // กำหนดขนาดของ canvas ให้ชัดเจน
  canvas.height = 400;
  canvas.width = canvas.parentElement.offsetWidth;
  
  chartInstances[canvasId] = new Chart(canvas, {
      type: 'bar',
      data: {
          labels,
          datasets: [{
              label: labelText,
              data: values,
              backgroundColor: bgColor,
              barPercentage: 0.7,
              categoryPercentage: 0.8
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          onResize: function(chart, size) {
              // ป้องกันการ resize เกินขนาด
              if (size.height > 400) {
                  size.height = 400;
              }
          },
          plugins: {
              datalabels: {
                  display: true,
                  anchor: 'end',
                  align: 'top',
                  formatter: function(value) {
                      return Math.round(value * 10) / 10;
                  },
                  font: {
                      weight: 'bold',
                      size: 12
                  }
              },
              legend: {
                  display: true,
                  position: 'top',
                  labels: {
                      boxWidth: 12,
                      padding: 10
                  }
              },
              tooltip: {
                  displayColors: false
              }
          },
          scales: {
              y: {
                  beginAtZero: true,
                  ticks: {
                      precision: 0
                  }
              },
              x: {
                  ticks: {
                      autoSkip: true,
                      maxRotation: 45,
                      minRotation: 45
                  }
              }
          },
          animation: {
              duration: 500
          },
          layout: {
              padding: {
                  top: 20,
                  right: 20,
                  bottom: 10,
                  left: 10
              }
          },
          devicePixelRatio: 1
      },
      plugins: [ChartDataLabels]
  });
  
  // แก้ไขการขยายหลังจากสร้างกราฟ
  fixChartResizing(canvasId);
}

// วาดกราฟวงกลม (Pie Chart)
function renderPieChart(canvasId, labels, values, colorsArray, chartTitle = "") {
  if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
      delete chartInstances[canvasId];
  }
  
  // จัดการกรณีไม่มีข้อมูล
  if (!labels || labels.length === 0) {
      showNoDataMessage(canvasId);
      return;
  }
  
  // เตรียม canvas ใหม่ที่สะอาด
  const canvas = prepareCanvasForChart(canvasId);
  if (!canvas) return;
  
  // กำหนดขนาดของ canvas ให้ชัดเจน
  canvas.height = 400;
  canvas.width = canvas.parentElement.offsetWidth;
  
  // คำนวณผลรวมของค่าทั้งหมด
  const total = values.reduce((acc, cur) => acc + Number(cur), 0);

  // แสดง data labels เฉพาะเมื่อมีข้อมูลไม่เกิน 8 รายการ
  const showDataLabels = labels.length <= 8;

  chartInstances[canvasId] = new Chart(canvas, {
      type: "pie",
      data: {
          labels,
          datasets: [{
              data: values,
              backgroundColor: colorsArray
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          onResize: function(chart, size) {
              // ป้องกันการ resize เกินขนาด
              if (size.height > 400) {
                  size.height = 400;
              }
          },
          plugins: {
              title: {
                  display: chartTitle !== "",
                  text: chartTitle,
                  font: { size: 16 }
              },
              datalabels: {
                  display: showDataLabels,
                  formatter: function(value, context) {
                      // แสดง label เฉพาะข้อมูลที่มีค่า > 0
                      if (value <= 0) return null;
                      
                      let label = context.chart.data.labels[context.dataIndex] || "";
                      
                      // ตัดข้อความให้สั้นลงถ้ายาวเกินไป
                      if (label.length > 15) {
                          label = label.substring(0, 15) + "...";
                      }
                      
                      // แสดงเปอร์เซ็นต์
                      const percent = ((value / total) * 100).toFixed(1) + '%';
                      
                      return label + "\n" + percent;
                  },
                  color: '#fff',
                  font: { weight: 'bold', size: 10 },
                  padding: 6,
                  clip: true,
                  offset: 5
              },
              tooltip: {
                  enabled: true,
                  displayColors: false,
                  callbacks: {
                      label: function(context) {
                          const value = context.raw;
                          const percent = ((value / total) * 100).toFixed(1);
                          return `${context.label}: ${value} (${percent}%)`;
                      },
                      title: function(context) {
                          return context[0].label;
                      }
                  }
              },
              legend: {
                  display: true,
                  position: 'bottom',
                  labels: {
                      // ปรับแต่ง legend เพื่อให้อ่านง่ายขึ้น
                      boxWidth: 12,
                      padding: 10,
                      generateLabels: function(chart) {
                          const data = chart.data;
                          if (data.labels.length && data.datasets.length) {
                              return data.labels.map(function(label, i) {
                                  const meta = chart.getDatasetMeta(0);
                                  const style = meta.controller.getStyle(i);
                                  const value = chart.data.datasets[0].data[i];
                                  
                                  // ตัดข้อความให้สั้นลงและเพิ่มจำนวน
                                  let displayLabel = label;
                                  if (displayLabel.length > 20) {
                                      displayLabel = displayLabel.substring(0, 20) + "...";
                                  }
                                  displayLabel += ` (${value})`;
                                  
                                  return {
                                      text: displayLabel,
                                      fillStyle: style.backgroundColor,
                                      hidden: isNaN(value) || value <= 0,
                                      index: i
                                  };
                              });
                          }
                          return [];
                      }
                  }
              }
          },
          layout: {
              padding: 20
          },
          animation: {
              duration: 500
          },
          devicePixelRatio: 1
      },
      plugins: [ChartDataLabels]
  });
  
  // แก้ไขการขยายหลังจากสร้างกราฟ
  fixChartResizing(canvasId);
}

// วาดกราฟแท่งเปรียบเทียบ (Grouped Bar Chart)
function renderGroupedBarChart(canvasId, labels, supplyValues, demandValues, supplyLabel, demandLabel) {
  if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
      delete chartInstances[canvasId];
  }
  
  // จัดการกรณีไม่มีข้อมูล
  if (!labels || labels.length === 0) {
      showNoDataMessage(canvasId);
      return;
  }
  
  // เตรียม canvas ใหม่ที่สะอาด
  const canvas = prepareCanvasForChart(canvasId);
  if (!canvas) return;
  
  // กำหนดขนาดของ canvas ให้ชัดเจน
  canvas.height = 400;
  canvas.width = canvas.parentElement.offsetWidth;
  
  chartInstances[canvasId] = new Chart(canvas, {
      type: 'bar',
      data: {
          labels,
          datasets: [
              {
                  label: supplyLabel,
                  data: supplyValues,
                  backgroundColor: '#66BB6A'
              },
              {
                  label: demandLabel,
                  data: demandValues,
                  backgroundColor: '#FF7043'
              }
          ]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          onResize: function(chart, size) {
              // ป้องกันการ resize เกินขนาด
              if (size.height > 400) {
                  size.height = 400;
              }
          },
          plugins: {
              datalabels: {
                  display: true,
                  anchor: 'end',
                  align: 'top',
                  formatter: Math.round,
                  font: {
                      weight: 'bold',
                      size: 10
                  }
              },
              tooltip: {
                  mode: 'index',
                  intersect: false,
                  displayColors: true
              },
              legend: {
                  display: true,
                  position: 'top',
                  labels: {
                      boxWidth: 12,
                      padding: 10
                  }
              }
          },
          scales: {
              x: { 
                  stacked: false, 
                  ticks: { 
                      font: { size: 12 },
                      autoSkip: true,
                      maxRotation: 45,
                      minRotation: 45
                  } 
              },
              y: { 
                  stacked: false, 
                  beginAtZero: true, 
                  ticks: { 
                      font: { size: 12 },
                      precision: 0
                  } 
              }
          },
          layout: {
              padding: {
                  top: 20,
                  right: 20,
                  bottom: 10,
                  left: 10
              }
          },
          animation: {
              duration: 500
          },
          devicePixelRatio: 1
      },
      plugins: [ChartDataLabels]
  });
  
  // แก้ไขการขยายหลังจากสร้างกราฟ
  fixChartResizing(canvasId);
}

// แสดงข้อความเมื่อไม่มีข้อมูล
function showNoDataMessage(canvasId) {
  // เตรียม canvas ใหม่
  const canvas = prepareCanvasForChart(canvasId);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  
  // กำหนดขนาดของ canvas
  canvas.height = 400;
  canvas.width = canvas.parentElement.offsetWidth;
  
  // Clear canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // กำหนดพื้นหลัง
  ctx.fillStyle = '#f8f9fa';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // วาดขอบ
  ctx.strokeStyle = '#dee2e6';
  ctx.lineWidth = 1;
  ctx.strokeRect(0, 0, canvas.width, canvas.height);
  
  // แสดงข้อความ
  ctx.font = '14px Arial';
  ctx.fillStyle = '#6c757d';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('No data available with current filters', canvas.width / 2, canvas.height / 2);
}