// studentanaly.js

// Dictionary to store Chart.js instances
const chartInstances = {};

document.addEventListener("DOMContentLoaded", function () {
    Promise.all([
        loadCategoryOptions(), 
        loadStatusOptions(),
        loadRewardOptions(),
        loadTeacherOptions()
      ]).then(() => {
        // Now that we've loaded all filter options, we can do the main logic
    loadStudentAnalytics();
}).catch(err => {
    console.error("Error loading filter options:", err);
    // even if they fail, still attempt to load main logic
    loadStudentAnalytics();
  });
});

function loadCategoryOptions() {
    return fetch("api/api.php?endpoint=categories-list")
      .then(res => res.json())
      .then(data => {
        const categorySelect = document.getElementById("category");
        categorySelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.job_categories_id;
          opt.textContent = item.categories_name;
          categorySelect.appendChild(opt);
        });
      });
  }
  
  function loadStatusOptions() {
    return fetch("api/api.php?endpoint=status-list")
      .then(res => res.json())
      .then(data => {
        const statusSelect = document.getElementById("status");
        statusSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.job_status_id;
          opt.textContent = item.job_status_name;
          statusSelect.appendChild(opt);
        });
      });
  }
  
  function loadRewardOptions() {
    return fetch("api/api.php?endpoint=reward-list")
      .then(res => res.json())
      .then(data => {
        const rewardSelect = document.getElementById("reward");
        rewardSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.reward_type_id;
          opt.textContent = item.reward_name;
          rewardSelect.appendChild(opt);
        });
      });
  }
  
  function loadTeacherOptions() {
    return fetch("api/api.php?endpoint=teacher-list")
      .then(res => res.json())
      .then(data => {
        const teacherSelect = document.getElementById("teacher");
        teacherSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.teachers_id;
          opt.textContent = item.name;
          teacherSelect.appendChild(opt);
        });
      });
  }

function applyFilters() {
    loadStudentAnalytics();
}

function loadStudentAnalytics() {
    const { start, end, category, status, reward, teacher } = getFilterValues();

    // 1) active-students
    const paramsStud = buildParams("active-students", start, end, category, status, reward, teacher);
    // Updated Registered Students Comparison section
    fetch("api/api.php?endpoint=active-students")
        .then(res => res.json())
        .then(data => {
            if (data && data[0]) {
                // Parse the three metrics
                const total = Number(data[0].total_students);
                const accepted = Number(data[0].accepted_students);
                const notAccepted = Number(data[0].not_accepted_students);

                // Optionally update a text element for the total students
                document.getElementById("totalStudents").textContent = total;

                // Render a bar chart comparing all three metrics
                renderBarChart(
                    "studentsChart", 
                    [ "Job Accepted", "No Job"], 
                    [ accepted, notAccepted], 
                    "Student Comparison", 
                    "#4B0082"
                );
            }
        })
        .catch(err => console.error("Error fetching active-students:", err));

    // 2) student-performance => rating (pie chart)
    let paramsPerf = buildParams("student-performance", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsPerf.toString())
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) return;
            document.getElementById("studentRating").textContent = data.length;
            const labels = data.map(d => d.name);
            const values = data.map(d => Number(d.avg_rating) || 0);
            renderPieChart("studentRatingChart", labels, values, ["#4B0082","#FF6B00","#FFA726","#66BB6A","#EC407A"]);
        })
        .catch(err => console.error("Error fetching student performance:", err));

    // 3) “applications-per-student” (optional)
    let paramsApps = buildParams("applications-per-student", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsApps.toString())
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) return;
            const total = data.reduce((acc, row) => acc + Number(row.total_apps), 0);
            document.getElementById("appsPerStudent").textContent = total + " total apps";
            renderBarChart("appsPerStudentChart",
                data.map(d => d.name),
                data.map(d => Number(d.total_apps)),
                "Applications per Student",
                "#FF6B00"
            );
        })
        .catch(err => console.error("Error fetching apps per student:", err));

    // 4) major-distribution
    let paramsMajor = buildParams("major-distribution", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsMajor.toString())
        .then(res => res.json())
        .then(data => {
            const labels = data.map(d => d.major_name || "No Major");
            const values = data.map(d => Number(d.total_students));
            renderPieChart("majorDistChart", labels, values, ["#66BB6A","#FF7043","#FFB74D","#26C6DA","#AB47BC"]);
        })
        .catch(err => console.error("Error fetching major-distribution:", err));

    // 5) avg-gpa (bar chart or single metric)
    let paramsGpa = buildParams("avg-gpa", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsGpa.toString())
        .then(res => res.json())
        .then(data => {
            if (!data || !data[0]) return;
            const gpaVal = Number(data[0].avg_gpa) || 0;
            document.getElementById("avgGpa").textContent = `Avg GPA: ${gpaVal.toFixed(2)}`;
            renderBarChart("avgGpaChart", ["GPA"], [gpaVal], "Average GPA", "#673AB7");
        })
        .catch(err => console.error("Error fetching avg-gpa:", err));

    // 6) top5-completed
    let paramsTop5 = buildParams("top5-completed", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsTop5.toString())
        .then(res => res.json())
        .then(data => {
            const labels = data.map(d => d.name);
            const values = data.map(d => Number(d.completed_count));
            renderBarChart("top5CompletedChart", labels, values, "Completed Count", "#FF6B00");
        })
        .catch(err => console.error("Error fetching top5-completed:", err));

    // 7) applications-over-time => line chart
    let paramsAppsTime = buildParams("applications-over-time", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsAppsTime.toString())
        .then(res => res.json())
        .then(data => {
            // data: [ {month: '2025-01', total_applications: 10}, ... ]
            const labels = data.map(d => d.month);
            const values = data.map(d => Number(d.total_applications));
            renderLineChart("appsOverTimeChart", labels, values, "Applications Over Time", "#FF5722");
        })
        .catch(err => console.error("Error fetching applications-over-time:", err));
}

// ============== Helper Functions ==============
function getFilterValues() {
    return {
        start: document.getElementById('startDate')?.value || '',
        end: document.getElementById('endDate')?.value || '',
        category: document.getElementById('category')?.value || '',
        status: document.getElementById('status')?.value || '',
        reward: document.getElementById('reward')?.value || '',
        teacher: document.getElementById('teacher')?.value || ''
    };
}

function buildParams(endpoint, start, end, category, status, reward, teacher) {
    const p = new URLSearchParams({ endpoint });
    if (start) p.set('start', start);
    if (end) p.set('end', end);
    if (category) p.set('category', category);
    if (status) p.set('status', status);
    if (reward) p.set('reward', reward);
    if (teacher) p.set('teacher', teacher);
    return p;
}

// Chart renderer wrappers (store in chartInstances)
function renderBarChart(canvasId, labels, values, labelText, bgColor) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "bar",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: values,
                backgroundColor: bgColor,
                barPercentage: 1,  // Adjust bar width (smaller = more spacing)
                categoryPercentage: 0.5  // Adjust space between categories
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: true,
                    anchor: 'end',
                    align: 'top',
                    offset: -4,  // Adjust this offset to lift labels further above the bar
                    formatter: function(value, context) {
                        const jobTitle = context.chart.data.labels[context.dataIndex];
                        // Shorten label if needed to avoid overlap
                        const shortTitle = jobTitle.length > 7 ? jobTitle.slice(0, 11) + '...' : jobTitle;
                        return shortTitle + ": " + value;
                    },
                    font: {
                        weight: 'bold',
                        size: 9  // Adjust font size as needed
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        callback: function(val, index) {
                            const maxLen = 100;
                            const label = this.getLabelForValue(val);
                            return (label.length > maxLen)
                                ? label.slice(0, maxLen) + '...'
                                : label;
                        }
                    }
                },
                y: {
                    beginAtZero: true
                }
            }
        },
        plugins: [ChartDataLabels]
    });
}

function renderPieChart(canvasId, labels, values, colorsArray, chartTitle = "") {
    // Calculate total sum of values
    const total = values.reduce((acc, cur) => acc + Number(cur), 0);
  
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
  
    // Set a threshold: show data labels if there are 8 or fewer slices
    const showDataLabels = labels.length <= 8;
  
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "pie",
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: colorsArray
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: chartTitle !== "",
                    text: chartTitle,
                    font: { size: 16 }
                },
                datalabels: {
                    display: showDataLabels,
                    anchor: 'center',
                    align: 'center',
                    offset: 2,  // conditionally display labels
                    formatter: function(value, context) {
                        let label = context.chart.data.labels[context.dataIndex] || "";
                        // Optionally, break the label into multiple lines if it's long:
                        if (label.length > 15) {
                            label = label.match(/.{1,15}/g).join("\n");
                        }
                        const total = context.chart.data.datasets[0].data.reduce((acc, cur) => acc + Number(cur), 0);
                        const percent = ((value / total) * 100).toFixed(1) + '%';
                        return label ;
                        
                    },
                    color: '#000000',
                    font: { weight: 'bold', size: 15 },
                    padding: 9,
                    clip: true
                },
                tooltip: {
                    enabled: true
                }
            }
        },
        plugins: [ChartDataLabels]
    });
  }

function renderLineChart(canvasId, labels, values, labelText, color) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "line",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: values,
                borderColor: color,
                fill: false
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}
